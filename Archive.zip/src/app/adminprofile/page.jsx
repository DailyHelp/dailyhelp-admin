import AdminProfile from "@/components/admin/AdminProfile"

export default function AdminProfilePage(){
    return(
        <div>
            <AdminProfile/>
        </div>
    )
}