import PageClient from "./PageClient";

export default function DisputesPage() {
  return <PageClient />;
}
