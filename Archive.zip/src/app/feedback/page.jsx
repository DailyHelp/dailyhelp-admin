import PageClient from "./PageClient";

export default function FeedbackPage() {
  return <PageClient />;
}
