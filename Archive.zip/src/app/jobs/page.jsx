import PageClient from "./PageClient";

export default function JobsPage() {
  return <PageClient />;
}
