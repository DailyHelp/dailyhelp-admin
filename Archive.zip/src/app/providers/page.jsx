import PageClient from "./PageClient";

export default function ProvidersPage() {
  return <PageClient />;
}
