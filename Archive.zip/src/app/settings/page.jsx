import SettingsPage from "./PageClient";

export default async function Page() {

  return <SettingsPage  />;
}
