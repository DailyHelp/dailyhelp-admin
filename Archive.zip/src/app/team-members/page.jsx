import TeamMembersProfilePage from "./PageClient";

export default async function Page() {

  return <TeamMembersProfilePage  />;
}
