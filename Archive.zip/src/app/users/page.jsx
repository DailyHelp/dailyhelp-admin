import PageClient from "./PageClient";

export default function UsersPage() {
  return <PageClient />;
}
